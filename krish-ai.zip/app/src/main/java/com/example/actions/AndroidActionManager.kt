package com.example.actions

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import com.example.model.ActionResult
import com.example.model.AndroidAction

class AndroidActionManager(private val context: Context) {

    private var isTorchOn = false

    /**
     * Executes the requested action safely and returns whether it succeeded
     * or was rejected/unavailable.
     */
    fun executeAction(action: AndroidAction): ActionResult {
        return when (action) {
            is AndroidAction.OpenYouTube -> openYouTube()
            is AndroidAction.OpenInstagram -> openInstagram()
            is AndroidAction.OpenWhatsApp -> openWhatsApp()
            is AndroidAction.OpenGoogle -> openGoogle()
            is AndroidAction.OpenSettings -> openSettings()
            is AndroidAction.OpenBluetoothSettings -> openBluetoothSettings()
            is AndroidAction.OpenWifiSettings -> openWifiSettings()
            is AndroidAction.OpenMaps -> openMaps(action.query)
            is AndroidAction.OpenPhone -> openPhone(action.phoneNumber)
            is AndroidAction.OpenMessages -> openMessages(action.recipient)
            is AndroidAction.OpenCamera -> openCamera()
            is AndroidAction.OpenGallery -> openGallery()
            is AndroidAction.OpenPlayStore -> openPlayStore()
            is AndroidAction.ToggleFlashlight -> toggleFlashlight(action.enable)
            is AndroidAction.ShowBattery -> getBatteryStatus()
            is AndroidAction.LaunchApp -> launchAppByName(action.appQuery)
        }
    }

    private fun openYouTube(): ActionResult {
        val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(appIntent)) {
            return launchSafely(appIntent, "YouTube app opened.", AndroidAction.OpenYouTube)
        }

        // Web fallback
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "Opening YouTube in browser.", AndroidAction.OpenYouTube)
    }

    private fun openInstagram(): ActionResult {
        val appIntent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (appIntent != null) {
            appIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            return launchSafely(appIntent, "Instagram launched.", AndroidAction.OpenInstagram)
        }

        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "Instagram opened in browser.", AndroidAction.OpenInstagram)
    }

    private fun openWhatsApp(): ActionResult {
        val appIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (appIntent != null) {
            appIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            return launchSafely(appIntent, "WhatsApp launched.", AndroidAction.OpenWhatsApp)
        }

        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "WhatsApp portal opened in browser.", AndroidAction.OpenWhatsApp)
    }

    private fun openGoogle(): ActionResult {
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, "")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(searchIntent)) {
            return launchSafely(searchIntent, "Google Search opened.", AndroidAction.OpenGoogle)
        }

        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "Google opened in browser.", AndroidAction.OpenGoogle)
    }

    private fun openSettings(): ActionResult {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(intent, "Device Settings opened.", AndroidAction.OpenSettings)
    }

    private fun openBluetoothSettings(): ActionResult {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(intent, "Bluetooth settings opened.", AndroidAction.OpenBluetoothSettings)
    }

    private fun openWifiSettings(): ActionResult {
        val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(intent, "Wi-Fi settings opened.", AndroidAction.OpenWifiSettings)
    }

    private fun openMaps(query: String?): ActionResult {
        val uri = if (query.isNullOrBlank()) {
            Uri.parse("geo:0,0?q=")
        } else {
            Uri.parse("geo:0,0?q=${Uri.encode(query)}")
        }
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(intent)) {
            return launchSafely(intent, "Google Maps opened.", AndroidAction.OpenMaps(query))
        }

        val webUri = if (query.isNullOrBlank()) {
            Uri.parse("https://maps.google.com")
        } else {
            Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")
        }
        val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "Maps opened in browser.", AndroidAction.OpenMaps(query))
    }

    private fun openPhone(phoneNumber: String?): ActionResult {
        val uri = if (phoneNumber.isNullOrBlank()) {
            Uri.parse("tel:")
        } else {
            Uri.parse("tel:$phoneNumber")
        }
        val intent = Intent(Intent.ACTION_DIAL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(intent, "Phone dialer opened.", AndroidAction.OpenPhone(phoneNumber))
    }

    private fun openMessages(recipient: String?): ActionResult {
        val uri = if (recipient.isNullOrBlank()) {
            Uri.parse("smsto:")
        } else {
            Uri.parse("smsto:$recipient")
        }
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(intent, "Messaging opened.", AndroidAction.OpenMessages(recipient))
    }

    private fun openCamera(): ActionResult {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(intent)) {
            return launchSafely(intent, "Camera opened.", AndroidAction.OpenCamera)
        }

        val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(captureIntent, "Camera launched.", AndroidAction.OpenCamera)
    }

    private fun openGallery(): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            type = "image/*"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(intent)) {
            return launchSafely(intent, "Gallery opened.", AndroidAction.OpenGallery)
        }

        val selectorIntent = Intent.makeMainSelectorActivity(
            Intent.ACTION_MAIN,
            Intent.CATEGORY_APP_GALLERY
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(selectorIntent, "Photos opened.", AndroidAction.OpenGallery)
    }

    private fun openPlayStore(): ActionResult {
        val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (canResolve(marketIntent)) {
            return launchSafely(marketIntent, "Google Play Store opened.", AndroidAction.OpenPlayStore)
        }

        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return launchSafely(webIntent, "Play Store opened in browser.", AndroidAction.OpenPlayStore)
    }

    private fun toggleFlashlight(enable: Boolean): ActionResult {
        val hasFlash = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
        if (!hasFlash) {
            return ActionResult(
                success = false,
                message = "Flashlight hardware feature is not supported on this device.",
                action = AndroidAction.ToggleFlashlight(enable)
            )
        }

        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return ActionResult(
                success = false,
                message = "Camera service is inaccessible.",
                action = AndroidAction.ToggleFlashlight(enable)
            )

        return try {
            val cameraIds = cameraManager.cameraIdList
            var flashCameraId: String? = null
            for (id in cameraIds) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    flashCameraId = id
                    break
                }
            }

            if (flashCameraId == null && cameraIds.isNotEmpty()) {
                flashCameraId = cameraIds[0]
            }

            if (flashCameraId != null) {
                cameraManager.setTorchMode(flashCameraId, enable)
                isTorchOn = enable
                val statusText = if (enable) "Flashlight turned ON." else "Flashlight turned OFF."
                ActionResult(
                    success = true,
                    message = statusText,
                    action = AndroidAction.ToggleFlashlight(enable)
                )
            } else {
                ActionResult(
                    success = false,
                    message = "No compatible camera flash unit found.",
                    action = AndroidAction.ToggleFlashlight(enable)
                )
            }
        } catch (e: CameraAccessException) {
            ActionResult(
                success = false,
                message = "Flashlight camera access error: ${e.localizedMessage}",
                action = AndroidAction.ToggleFlashlight(enable)
            )
        } catch (e: Exception) {
            ActionResult(
                success = false,
                message = "Unable to toggle flashlight: ${e.localizedMessage}",
                action = AndroidAction.ToggleFlashlight(enable)
            )
        }
    }

    private fun getBatteryStatus(): ActionResult {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (batteryIntent == null) {
            return ActionResult(
                success = false,
                message = "Unable to read battery telemetry from system.",
                action = AndroidAction.ShowBattery
            )
        }

        val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val batteryPct = if (level >= 0 && scale > 0) {
            (level * 100 / scale)
        } else {
            level
        }

        val statusMsg = "Battery is currently at $batteryPct%${if (isCharging) " (Charging)" else ""}."
        return ActionResult(
            success = true,
            message = statusMsg,
            action = AndroidAction.ShowBattery,
            batteryPercentage = batteryPct,
            isCharging = isCharging
        )
    }

    private fun launchAppByName(query: String): ActionResult {
        val pm = context.packageManager
        val cleanQuery = query.lowercase().trim()

        try {
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (appInfo in installedApps) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (label.contains(cleanQuery) || cleanQuery.contains(label)) {
                    val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        return launchSafely(
                            launchIntent,
                            "Opening ${pm.getApplicationLabel(appInfo)}.",
                            AndroidAction.LaunchApp(query)
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        return ActionResult(
            success = false,
            message = "Could not find an installed app matching \"$query\".",
            action = AndroidAction.LaunchApp(query)
        )
    }

    private fun canResolve(intent: Intent): Boolean {
        return try {
            intent.resolveActivity(context.packageManager) != null
        } catch (_: Exception) {
            false
        }
    }

    private fun launchSafely(intent: Intent, successMessage: String, action: AndroidAction): ActionResult {
        return try {
            context.startActivity(intent)
            ActionResult(success = true, message = successMessage, action = action)
        } catch (e: Exception) {
            ActionResult(
                success = false,
                message = "Android system could not launch action: ${e.localizedMessage ?: "Application unavailable"}",
                action = action
            )
        }
    }
}
