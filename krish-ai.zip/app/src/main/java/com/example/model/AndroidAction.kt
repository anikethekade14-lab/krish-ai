package com.example.model

sealed interface AndroidAction {
    val description: String

    object OpenYouTube : AndroidAction {
        override val description: String = "Open YouTube"
    }
    object OpenInstagram : AndroidAction {
        override val description: String = "Open Instagram"
    }
    object OpenWhatsApp : AndroidAction {
        override val description: String = "Open WhatsApp"
    }
    object OpenGoogle : AndroidAction {
        override val description: String = "Open Google"
    }
    object OpenSettings : AndroidAction {
        override val description: String = "Open Settings"
    }
    object OpenBluetoothSettings : AndroidAction {
        override val description: String = "Open Bluetooth Settings"
    }
    object OpenWifiSettings : AndroidAction {
        override val description: String = "Open Wi-Fi Settings"
    }
    data class OpenMaps(val query: String? = null) : AndroidAction {
        override val description: String = if (query.isNullOrBlank()) "Open Maps" else "Search Maps for $query"
    }
    data class OpenPhone(val phoneNumber: String? = null) : AndroidAction {
        override val description: String = if (phoneNumber.isNullOrBlank()) "Open Phone dialer" else "Dial $phoneNumber"
    }
    data class OpenMessages(val recipient: String? = null) : AndroidAction {
        override val description: String = if (recipient.isNullOrBlank()) "Open Messages" else "Message $recipient"
    }
    object OpenCamera : AndroidAction {
        override val description: String = "Open Camera"
    }
    object OpenGallery : AndroidAction {
        override val description: String = "Open Gallery / Photos"
    }
    object OpenPlayStore : AndroidAction {
        override val description: String = "Open Google Play Store"
    }
    data class ToggleFlashlight(val enable: Boolean) : AndroidAction {
        override val description: String = if (enable) "Turn flashlight ON" else "Turn flashlight OFF"
    }
    object ShowBattery : AndroidAction {
        override val description: String = "Check Battery Level"
    }
    data class LaunchApp(val appQuery: String) : AndroidAction {
        override val description: String = "Open App: $appQuery"
    }
}

data class ActionResult(
    val success: Boolean,
    val message: String,
    val action: AndroidAction? = null,
    val batteryPercentage: Int? = null,
    val isCharging: Boolean? = null
)
