package com.example.model

enum class LanguageMode(
    val displayName: String,
    val nativeName: String,
    val localeTag: String?,
    val instruction: String
) {
    AUTO(
        displayName = "Auto Detect",
        nativeName = "Auto",
        localeTag = null,
        instruction = "Detect the user's language automatically and respond in that same language (Marathi, Hindi, or English)."
    ),
    ENGLISH(
        displayName = "English",
        nativeName = "English",
        localeTag = "en-IN",
        instruction = "Respond naturally and fluently in English."
    ),
    HINDI(
        displayName = "Hindi",
        nativeName = "हिन्दी",
        localeTag = "hi-IN",
        instruction = "Respond naturally and fluently in Hindi (हिन्दी) using Devanagari script."
    ),
    MARATHI(
        displayName = "Marathi",
        nativeName = "मराठी",
        localeTag = "mr-IN",
        instruction = "Respond naturally and fluently in Marathi (मराठी) using Devanagari script."
    )
}
