package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.model.LanguageMode
import java.util.Locale

class VoiceInputManager(
    private val context: Context,
    private val listener: VoiceListener
) {
    interface VoiceListener {
        fun onListeningStarted()
        fun onListeningStopped()
        fun onRmsChanged(rmsdB: Float)
        fun onSpeechResult(recognizedText: String)
        fun onSpeechError(errorMessage: String, isFatal: Boolean)
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isCurrentlyListening = false

    val isListening: Boolean
        get() = isCurrentlyListening

    fun startListening(languageMode: LanguageMode) {
        mainHandler.post {
            if (isCurrentlyListening) {
                stopListening()
                return@post
            }

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                listener.onSpeechError(
                    "Speech recognition is unavailable on this device. You can type queries directly.",
                    isFatal = true
                )
                return@post
            }

            try {
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createRecognitionListener())
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)

                    // Configure language tag if specific language chosen
                    languageMode.localeTag?.let { tag ->
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
                    } ?: run {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    }
                }

                speechRecognizer?.startListening(intent)
                isCurrentlyListening = true
                listener.onListeningStarted()
            } catch (e: Exception) {
                isCurrentlyListening = false
                listener.onSpeechError("Microphone initialization error: ${e.localizedMessage}", isFatal = false)
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                if (isCurrentlyListening) {
                    speechRecognizer?.stopListening()
                    isCurrentlyListening = false
                    listener.onListeningStopped()
                }
            } catch (_: Exception) {}
        }
    }

    fun cancel() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                isCurrentlyListening = false
                listener.onListeningStopped()
            } catch (_: Exception) {}
        }
    }

    fun destroy() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
                isCurrentlyListening = false
            } catch (_: Exception) {}
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}

            override fun onBeginningOfSpeech() {
                listener.onListeningStarted()
            }

            override fun onRmsChanged(rmsdB: Float) {
                listener.onRmsChanged(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isCurrentlyListening = false
                listener.onListeningStopped()
            }

            override fun onError(error: Int) {
                isCurrentlyListening = false
                listener.onListeningStopped()

                val (message, fatal) = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> Pair("No speech recognized. Tap to try again.", false)
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> Pair("Speech timed out.", false)
                    SpeechRecognizer.ERROR_AUDIO -> Pair("Audio recording error.", false)
                    SpeechRecognizer.ERROR_CLIENT -> Pair("Speech client error.", false)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> Pair("Microphone permission required.", true)
                    SpeechRecognizer.ERROR_NETWORK -> Pair("Network error during speech recognition.", false)
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> Pair("Network timeout during speech recognition.", false)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> Pair("Speech recognizer busy, resetting...", false)
                    SpeechRecognizer.ERROR_SERVER -> Pair("Server error during speech recognition.", false)
                    else -> Pair("Speech error code: $error", false)
                }

                // Only notify if meaningful to user, preventing repetitive loops
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    listener.onSpeechError(message, fatal)
                }
            }

            override fun onResults(results: Bundle?) {
                isCurrentlyListening = false
                listener.onListeningStopped()

                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognizedText = matches?.firstOrNull()?.trim()
                if (!recognizedText.isNullOrEmpty()) {
                    listener.onSpeechResult(recognizedText)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
