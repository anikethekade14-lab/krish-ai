package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.model.LanguageMode
import java.util.Locale

class TextToSpeechManager(
    private val context: Context,
    private val listener: TtsListener
) : TextToSpeech.OnInitListener {

    interface TtsListener {
        fun onTtsReady()
        fun onSpeakingStarted()
        fun onSpeakingDone()
        fun onSpeakingError(error: String)
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    listener.onSpeakingStarted()
                }

                override fun onDone(utteranceId: String?) {
                    listener.onSpeakingDone()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    listener.onSpeakingDone()
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    listener.onSpeakingDone()
                }
            })
            listener.onTtsReady()
        } else {
            isInitialized = false
            listener.onSpeakingError("Text-to-Speech initialization failed on this device.")
        }
    }

    fun speak(text: String, languageMode: LanguageMode) {
        if (!isInitialized || tts == null) {
            return
        }

        // Clean out markdown symbols like **, *, ` etc. for smoother speech
        val cleanedText = text
            .replace(Regex("[*#`_~]"), "")
            .replace(Regex("\\[.*?\\]"), "")
            .trim()

        if (cleanedText.isEmpty()) return

        // Set appropriate language locale
        applyLanguage(languageMode, cleanedText)

        val utteranceId = "KRISH_SPEECH_${System.currentTimeMillis()}"
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    private fun applyLanguage(languageMode: LanguageMode, text: String) {
        val targetLocale = when (languageMode) {
            LanguageMode.MARATHI -> Locale.forLanguageTag("mr-IN")
            LanguageMode.HINDI -> Locale.forLanguageTag("hi-IN")
            LanguageMode.ENGLISH -> Locale.US
            LanguageMode.AUTO -> detectLanguageFromText(text)
        }

        try {
            val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                tts?.language = targetLocale
            } else {
                // Fallback to Hindi or default if Marathi TTS pack is missing
                if (targetLocale.language == "mr") {
                    val hindiLocale = Locale.forLanguageTag("hi-IN")
                    if ((tts?.isLanguageAvailable(hindiLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                        tts?.language = hindiLocale
                        return
                    }
                }
                tts?.language = Locale.getDefault()
            }
        } catch (_: Exception) {
            tts?.language = Locale.getDefault()
        }
    }

    private fun detectLanguageFromText(text: String): Locale {
        // Simple Devanagari script detection range \u0900-\u097F
        var devanagariCount = 0
        for (char in text) {
            if (char in '\u0900'..'\u097F') {
                devanagariCount++
            }
        }
        return if (devanagariCount > 3) {
            Locale.forLanguageTag("hi-IN")
        } else {
            Locale.US
        }
    }

    fun stop() {
        try {
            tts?.stop()
            listener.onSpeakingDone()
        } catch (_: Exception) {}
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {}
    }
}
