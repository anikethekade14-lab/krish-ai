package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.avatar.AvatarHologramRenderer
import com.example.avatar.Krish3DCharacterView
import com.example.model.AssistantState
import com.example.ui.components.ConversationOverlay
import com.example.ui.components.HudStatusIndicator
import com.example.ui.components.HudTopBar
import com.example.ui.components.MicButton
import com.example.ui.components.QuickActionHud
import com.example.ui.components.SettingsDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainScreen(
    viewModel: KrishAiViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val assistantState by viewModel.assistantState.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val languageMode by viewModel.languageMode.collectAsStateWithLifecycle()
    val audioAmplitude by viewModel.audioAmplitude.collectAsStateWithLifecycle()
    val batteryPercentage by viewModel.batteryPercentage.collectAsStateWithLifecycle()
    val isCharging by viewModel.isCharging.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val systemNotice by viewModel.systemNotice.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showMicPermissionDeniedDialog by remember { mutableStateOf(false) }
    var is3DMode by remember { mutableStateOf(true) }

    val avatarRenderer = remember { AvatarHologramRenderer() }
    val snackbarHostState = remember { SnackbarHostState() }

    // Audio recording permission launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleListening()
        } else {
            showMicPermissionDeniedDialog = true
        }
    }

    // React to system notices (toast/snackbar)
    LaunchedEffect(systemNotice) {
        systemNotice?.let { notice ->
            snackbarHostState.showSnackbar(notice)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = CyberDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            CyberDark,
                            CyberSurface.copy(alpha = 0.85f),
                            CyberDark
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Top Futuristic HUD Bar
                HudTopBar(
                    currentLanguage = languageMode,
                    onLanguageSelected = { viewModel.setLanguage(it) },
                    batteryPercentage = batteryPercentage,
                    isCharging = isCharging,
                    onOpenSettings = { showSettingsDialog = true },
                    is3DMode = is3DMode,
                    onToggle3DMode = { is3DMode = !is3DMode }
                )

                // Quick Action Shortcuts HUD
                QuickActionHud(
                    onTriggerAction = { action ->
                        viewModel.triggerActionDirectly(action)
                    }
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Small Status Indicator (Listening, Thinking, Speaking, Idle)
                HudStatusIndicator(state = assistantState)

                // 2. Center Animated 3D Anime Assistant Character (Scaled & Centered, never overlaps chat/controls)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (is3DMode) {
                        Krish3DCharacterView(
                            state = assistantState,
                            audioAmplitude = audioAmplitude,
                            modifier = Modifier.fillMaxSize(),
                            onModelImported = { msg ->
                                viewModel.postSystemNotice(msg)
                            }
                        )
                    } else {
                        avatarRenderer.RenderAvatar(
                            state = assistantState,
                            audioAmplitude = audioAmplitude,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // 3. Bottom Controls Area (Conversation Log, Text Input & Arc Reactor Mic Button)
                ConversationOverlay(
                    messages = messages,
                    onSendMessage = { text ->
                        viewModel.processUserQuery(text, isVoiceInput = false)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Futuristic Arc Reactor Mic Button
                MicButton(
                    state = assistantState,
                    isListening = isListening,
                    audioAmplitude = audioAmplitude,
                    onClick = {
                        val hasMicPermission = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED

                        if (hasMicPermission) {
                            viewModel.toggleListening()
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            // Settings Dialog
            if (showSettingsDialog) {
                SettingsDialog(
                    currentApiKey = viewModel.getCustomApiKey(),
                    onSaveApiKey = { key ->
                        viewModel.saveCustomApiKey(key)
                    },
                    onClearSession = {
                        viewModel.clearConversationHistory()
                    },
                    onDismiss = { showSettingsDialog = false }
                )
            }

            // Microphone Permission Dialog
            if (showMicPermissionDeniedDialog) {
                AlertDialog(
                    onDismissRequest = { showMicPermissionDeniedDialog = false },
                    title = { Text("Microphone Permission Required", color = NeonCyan) },
                    text = {
                        Text(
                            "KRISH AI needs microphone access to listen to your voice commands. Please grant the permission to enable hands-free interaction.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showMicPermissionDeniedDialog = false
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                        ) {
                            Text("Grant Permission", color = CyberDark)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showMicPermissionDeniedDialog = false }) {
                            Text("Type Instead", color = TextPrimary)
                        }
                    },
                    containerColor = CyberSurface
                )
            }
        }
    }
}
