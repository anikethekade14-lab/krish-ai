package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0xFF00838F)
val ElectricBlue = Color(0xFF00B4D8)
val NeonPurple = Color(0xFF9D4EDD)
val NeonPurpleLight = Color(0xFFC77DFF)
val CyberDark = Color(0xFF070B14)
val CyberSurface = Color(0xFF0F172A)
val CyberSurfaceVariant = Color(0xFF1E293B)
val CyberBorder = Color(0x3300F0FF)
val CyberGreen = Color(0xFF10B981)
val CyberYellow = Color(0xFFF59E0B)
val CyberRed = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextCyan = Color(0xFF67E8F9)

