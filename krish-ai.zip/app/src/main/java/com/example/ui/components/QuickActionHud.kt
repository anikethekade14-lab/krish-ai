package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AndroidAction
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary

@Composable
fun QuickActionHud(
    onTriggerAction: (AndroidAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuickActionChip(
            title = "Torch",
            icon = Icons.Default.FlashlightOn,
            tag = "action_chip_torch",
            onClick = { onTriggerAction(AndroidAction.ToggleFlashlight(true)) }
        )
        QuickActionChip(
            title = "Battery",
            icon = Icons.Default.BatteryFull,
            tag = "action_chip_battery",
            onClick = { onTriggerAction(AndroidAction.ShowBattery) }
        )
        QuickActionChip(
            title = "YouTube",
            icon = Icons.Default.PlayArrow,
            tag = "action_chip_youtube",
            onClick = { onTriggerAction(AndroidAction.OpenYouTube) }
        )
        QuickActionChip(
            title = "WhatsApp",
            icon = Icons.Default.Share,
            tag = "action_chip_whatsapp",
            onClick = { onTriggerAction(AndroidAction.OpenWhatsApp) }
        )
        QuickActionChip(
            title = "Camera",
            icon = Icons.Default.CameraAlt,
            tag = "action_chip_camera",
            onClick = { onTriggerAction(AndroidAction.OpenCamera) }
        )
        QuickActionChip(
            title = "Maps",
            icon = Icons.Default.Map,
            tag = "action_chip_maps",
            onClick = { onTriggerAction(AndroidAction.OpenMaps()) }
        )
        QuickActionChip(
            title = "Settings",
            icon = Icons.Default.Settings,
            tag = "action_chip_settings",
            onClick = { onTriggerAction(AndroidAction.OpenSettings) }
        )
    }
}

@Composable
private fun QuickActionChip(
    title: String,
    icon: ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .testTag(tag)
            .clip(RoundedCornerShape(12.dp))
            .background(CyberDark.copy(alpha = 0.75f))
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NeonCyan,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 11.sp
            )
        }
    }
}
