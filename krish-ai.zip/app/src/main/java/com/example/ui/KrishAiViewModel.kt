package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.actions.AndroidActionManager
import com.example.ai.KrishAiBrain
import com.example.model.AndroidAction
import com.example.model.AssistantState
import com.example.model.ChatMessage
import com.example.model.LanguageMode
import com.example.model.MessageRole
import com.example.voice.TextToSpeechManager
import com.example.voice.VoiceInputManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class KrishAiViewModel(application: Application) : AndroidViewModel(application),
    VoiceInputManager.VoiceListener,
    TextToSpeechManager.TtsListener {

    private val brain = KrishAiBrain()
    private val actionManager = AndroidActionManager(application.applicationContext)
    private val voiceInputManager = VoiceInputManager(application.applicationContext, this)
    private val ttsManager = TextToSpeechManager(application.applicationContext, this)

    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _languageMode = MutableStateFlow(LanguageMode.AUTO)
    val languageMode: StateFlow<LanguageMode> = _languageMode.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

    private val _batteryPercentage = MutableStateFlow<Int?>(null)
    val batteryPercentage: StateFlow<Int?> = _batteryPercentage.asStateFlow()

    private val _isCharging = MutableStateFlow<Boolean?>(null)
    val isCharging: StateFlow<Boolean?> = _isCharging.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _systemNotice = MutableStateFlow<String?>(null)
    val systemNotice: StateFlow<String?> = _systemNotice.asStateFlow()

    init {
        // Initial greeting
        _messages.value = listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "KRISH AI online. How can I assist you today?"
            )
        )
        refreshBatteryTelemetry()
    }

    fun setLanguage(mode: LanguageMode) {
        _languageMode.value = mode
        val ack = when (mode) {
            LanguageMode.MARATHI -> "भाषा मराठी निवडली आहे. मी तयार आहे."
            LanguageMode.HINDI -> "हिन्दी भाषा चुनी गई है। मैं तैयार हूँ।"
            LanguageMode.ENGLISH -> "English mode engaged. Standing by."
            LanguageMode.AUTO -> "Auto-detect language engaged."
        }
        addSystemMessage(ack)
    }

    fun toggleListening() {
        if (_isListening.value) {
            voiceInputManager.stopListening()
            _assistantState.value = AssistantState.IDLE
        } else {
            ttsManager.stop()
            voiceInputManager.startListening(_languageMode.value)
        }
    }

    fun stopSpeaking() {
        ttsManager.stop()
        _assistantState.value = AssistantState.IDLE
    }

    fun processUserQuery(query: String, isVoiceInput: Boolean) {
        if (query.isBlank()) return

        // 1. Add User Message
        val userMsg = ChatMessage(
            role = MessageRole.USER,
            text = query,
            isVoiceTranscript = isVoiceInput
        )
        addMessage(userMsg)

        // 2. Set Thinking state
        _assistantState.value = AssistantState.THINKING

        viewModelScope.launch {
            try {
                // Check if direct local action can execute immediately
                val directAction = brain.parseDirectAction(query)
                var actionExecutionReport: String? = null

                if (directAction != null) {
                    val result = actionManager.executeAction(directAction)
                    actionExecutionReport = result.message
                    if (directAction is AndroidAction.ShowBattery) {
                        _batteryPercentage.value = result.batteryPercentage
                        _isCharging.value = result.isCharging
                    }
                }

                // Query Gemini Neural Brain
                val brainResponse = brain.think(
                    userMessage = query,
                    languageMode = _languageMode.value,
                    isVoiceMode = isVoiceInput
                )

                // If brain detected an action that wasn't already run
                if (directAction == null && brainResponse.action != null) {
                    val result = actionManager.executeAction(brainResponse.action)
                    actionExecutionReport = result.message
                    if (brainResponse.action is AndroidAction.ShowBattery) {
                        _batteryPercentage.value = result.batteryPercentage
                        _isCharging.value = result.isCharging
                    }
                }

                val finalSpeechText = if (actionExecutionReport != null && !brainResponse.replyText.contains(actionExecutionReport)) {
                    "${brainResponse.replyText} $actionExecutionReport"
                } else {
                    brainResponse.replyText
                }

                // Add Assistant Message
                val assistantMsg = ChatMessage(
                    role = MessageRole.ASSISTANT,
                    text = brainResponse.replyText,
                    actionReport = actionExecutionReport
                )
                addMessage(assistantMsg)

                // Speak response via TTS
                _assistantState.value = AssistantState.SPEAKING
                ttsManager.speak(finalSpeechText, _languageMode.value)

            } catch (e: Exception) {
                _assistantState.value = AssistantState.ERROR
                val errMsg = "Error processing command: ${e.localizedMessage}"
                addMessage(ChatMessage(role = MessageRole.ASSISTANT, text = errMsg))
            }
        }
    }

    fun triggerActionDirectly(action: AndroidAction) {
        val result = actionManager.executeAction(action)
        if (action is AndroidAction.ShowBattery) {
            _batteryPercentage.value = result.batteryPercentage
            _isCharging.value = result.isCharging
        }
        val assistantMsg = ChatMessage(
            role = MessageRole.ASSISTANT,
            text = result.message,
            actionReport = if (result.success) "Executed successfully" else "Failed: ${result.message}"
        )
        addMessage(assistantMsg)
        _assistantState.value = AssistantState.SPEAKING
        ttsManager.speak(result.message, _languageMode.value)
    }

    fun updateApiKey(apiKey: String) {
        brain.setCustomApiKey(apiKey)
        addSystemMessage("API Key configuration updated.")
    }

    fun getEffectiveApiKey(): String = brain.getEffectiveApiKey()

    fun clearSessionHistory() {
        brain.clearSessionHistory()
        _messages.value = listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "Session memory reset. System ready."
            )
        )
        _assistantState.value = AssistantState.IDLE
    }

    fun dismissSystemNotice() {
        _systemNotice.value = null
    }

    private fun refreshBatteryTelemetry() {
        val res = actionManager.executeAction(AndroidAction.ShowBattery)
        _batteryPercentage.value = res.batteryPercentage
        _isCharging.value = res.isCharging
    }

    private fun addMessage(msg: ChatMessage) {
        val list = _messages.value.toMutableList()
        list.add(msg)
        // Keep list bounded to 40 items to conserve RAM on low-end 4GB phones
        if (list.size > 40) {
            list.removeAt(0)
        }
        _messages.value = list
    }

    private fun addSystemMessage(text: String) {
        addMessage(ChatMessage(role = MessageRole.SYSTEM, text = text))
    }

    // VoiceListener Callbacks
    override fun onListeningStarted() {
        _isListening.value = true
        _assistantState.value = AssistantState.LISTENING
    }

    override fun onListeningStopped() {
        _isListening.value = false
        if (_assistantState.value == AssistantState.LISTENING) {
            _assistantState.value = AssistantState.IDLE
        }
    }

    override fun onRmsChanged(rmsdB: Float) {
        _audioAmplitude.value = rmsdB
    }

    override fun onSpeechResult(recognizedText: String) {
        processUserQuery(recognizedText, isVoiceInput = true)
    }

    override fun onSpeechError(errorMessage: String, isFatal: Boolean) {
        _isListening.value = false
        if (isFatal) {
            _assistantState.value = AssistantState.ERROR
            _systemNotice.value = errorMessage
        } else {
            _assistantState.value = AssistantState.IDLE
        }
    }

    // TtsListener Callbacks
    override fun onTtsReady() {}

    override fun onSpeakingStarted() {
        _assistantState.value = AssistantState.SPEAKING
    }

    override fun onSpeakingDone() {
        if (_assistantState.value == AssistantState.SPEAKING) {
            _assistantState.value = AssistantState.IDLE
        }
    }

    override fun onSpeakingError(error: String) {
        if (_assistantState.value == AssistantState.SPEAKING) {
            _assistantState.value = AssistantState.IDLE
        }
    }

    fun clearNotice() {
        _systemNotice.value = null
    }

    fun postSystemNotice(msg: String) {
        _systemNotice.value = msg
    }

    fun getCustomApiKey(): String {
        return brain.getEffectiveApiKey()
    }

    fun saveCustomApiKey(key: String) {
        brain.setCustomApiKey(key)
        _systemNotice.value = "API key updated for active session"
    }

    fun clearConversationHistory() {
        brain.clearSessionHistory()
        _messages.value = listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "KRISH AI session reset. How may I assist you?"
            )
        )
        _systemNotice.value = "Conversation memory cleared"
    }

    override fun onCleared() {
        super.onCleared()
        voiceInputManager.destroy()
        ttsManager.shutdown()
    }
}
