package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.MainScreen
import com.example.ui.KrishAiViewModel
import com.example.ui.theme.KrishAiTheme

class MainActivity : ComponentActivity() {
    private val viewModel: KrishAiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KrishAiTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}

