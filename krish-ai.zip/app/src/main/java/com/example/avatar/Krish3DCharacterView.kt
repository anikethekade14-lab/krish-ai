package com.example.avatar

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.AssistantState
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextSecondary

@Composable
fun Krish3DCharacterView(
    state: AssistantState,
    audioAmplitude: Float,
    modifier: Modifier = Modifier,
    onModelImported: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    var manualPose by remember { mutableStateOf<String?>(null) }

    val renderer = remember {
        Krish3DGlRenderer(context, Model3DManager.getModelFile())
    }

    LaunchedEffect(state, audioAmplitude, manualPose) {
        renderer.assistantState = state
        renderer.audioAmplitude = audioAmplitude
        renderer.manualPoseOverride = manualPose
    }

    val modelPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val result = Model3DManager.importModelFromUri(context, uri)
            result.onSuccess { file ->
                renderer.setModelFile(file)
                val msg = "Loaded 3D model: ${file.name}"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                onModelImported?.invoke(msg)
            }.onFailure { err ->
                Toast.makeText(context, "Failed to load model: ${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        renderer.touchRotY += dragAmount.x * 0.40f
                        renderer.touchRotX = (renderer.touchRotX + dragAmount.y * 0.30f).coerceIn(-25f, 25f)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // 1. OpenGL ES SurfaceView (configured so it stays behind UI overlays)
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(8, 8, 8, 8, 16, 0)
                    holder.setFormat(PixelFormat.TRANSLUCENT)
                    // Use setZOrderMediaOverlay(true) so it renders cleanly within its view hierarchy
                    // without punching over dialogue boxes or text inputs
                    setZOrderMediaOverlay(true)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("krish_3d_surface_view"),
            update = {
                renderer.assistantState = state
                renderer.audioAmplitude = audioAmplitude
                renderer.manualPoseOverride = manualPose
            }
        )

        // 2. Futuristic Telemetry Badge (Compact, non-intrusive)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(CyberSurface.copy(alpha = 0.82f))
                    .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(
                            when (state) {
                                AssistantState.LISTENING -> CyberGreen
                                AssistantState.THINKING -> NeonPurple
                                AssistantState.SPEAKING -> ElectricBlue
                                else -> NeonCyan
                            }
                        )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "3D LIVE • 60 FPS",
                    color = NeonCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )

                Spacer(modifier = Modifier.width(8.dp))

                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = "Reset Camera View",
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable {
                            renderer.touchRotX = 0f
                            renderer.touchRotY = 0f
                        }
                )

                Spacer(modifier = Modifier.width(6.dp))

                Icon(
                    imageVector = Icons.Default.FileOpen,
                    contentDescription = "Import 3D Model",
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable {
                            modelPickerLauncher.launch("*/*")
                        }
                )
            }
        }

        // 3. Compact Pose Selector (At bottom of 3D frame, strictly within bounds)
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CompactPoseChip("Auto", manualPose == null) { manualPose = null }
            CompactPoseChip("Idle", manualPose == "idle") { manualPose = if (manualPose == "idle") null else "idle" }
            CompactPoseChip("Listen", manualPose == "listen") { manualPose = if (manualPose == "listen") null else "listen" }
            CompactPoseChip("Think", manualPose == "think") { manualPose = if (manualPose == "think") null else "think" }
            CompactPoseChip("Speak", manualPose == "speak") { manualPose = if (manualPose == "speak") null else "speak" }
            CompactPoseChip("Happy", manualPose == "happy") { manualPose = if (manualPose == "happy") null else "happy" }
        }
    }
}

@Composable
private fun CompactPoseChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (isSelected) NeonCyan.copy(alpha = 0.22f)
                else CyberSurface.copy(alpha = 0.65f)
            )
            .border(
                width = 0.8.dp,
                color = if (isSelected) NeonCyan else NeonCyan.copy(alpha = 0.18f),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) NeonCyan else TextSecondary,
            fontSize = 9.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
