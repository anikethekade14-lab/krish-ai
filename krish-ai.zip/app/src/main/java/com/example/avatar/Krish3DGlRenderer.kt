package com.example.avatar

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import com.example.R
import com.example.model.AssistantState
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

/**
 * Advanced, lightweight 3D OpenGL ES 2.0 Skeletal & Expression Renderer for KRISH AI.
 * Implements a real 3D bone rig (head pitch/yaw/roll, neck translate, breathing chest,
 * shoulder lift, hair spring inertia) and blend shapes (organic eyelid blink, speech visemes,
 * friendly smile) running at a smooth 60 FPS on low-RAM (4GB) Android 16 devices.
 */
class Krish3DGlRenderer(
    private val context: Context,
    private var customGlbFile: File? = null
) : GLSurfaceView.Renderer {

    companion object {
        private const val TAG = "Krish3DGlRenderer"

        private const val VERTEX_SHADER = """
            uniform mat4 uMVPMatrix;
            uniform mat4 uModelMatrix;
            uniform vec3 uCameraPos;
            uniform float uTime;

            // 3D Skeletal Rig Uniforms
            uniform float uHeadPitch;     // Head nod / pitch (around X)
            uniform float uHeadYaw;       // Head turn / yaw (around Y)
            uniform float uHeadRoll;      // Head tilt / roll (around Z)
            uniform vec3  uHeadOffset;    // Forward attentive translation
            uniform float uShoulderLift;  // Shoulder breathing heave
            uniform float uChestBreathing;// Torso volume expansion
            uniform float uHairSway;      // Secondary hair inertia

            // BlendShape / Morph Uniforms
            uniform float uMouthOpen;     // Natural speech viseme (0.0 to 0.40)
            uniform float uMouthSmile;    // Friendly smile corner lift (0.0 to 1.0)
            uniform float uEyeBlink;      // Eyelid closure morph (0.0 to 1.0)

            attribute vec3 aPosition;
            attribute vec3 aNormal;
            attribute vec2 aTexCoordinate;

            varying vec3 vNormal;
            varying vec3 vWorldPos;
            varying vec2 vTexCoordinate;
            varying float vRim;

            void main() {
                vec3 pos = aPosition;
                vec3 norm = aNormal;
                vec2 uv = aTexCoordinate;

                // 1. CHEST & SHOULDERS SKELETAL DEFORMATION
                // Torso expansion along normals and +Z forward heave (y in [-0.25, 0.35])
                float chestFactor = exp(-pow((pos.y - 0.05) / 0.32, 2.0)) * clamp(1.0 - abs(pos.x) / 0.50, 0.0, 1.0);
                pos.z += uChestBreathing * 0.024 * chestFactor;
                pos.x += pos.x * (uChestBreathing * 0.012 * chestFactor);

                // Shoulder vertical movement with breathing (shoulders at |x| > 0.20, y between -0.05 and 0.35)
                float shoulderFactor = clamp((abs(pos.x) - 0.20) / 0.22, 0.0, 1.0) 
                                     * clamp((pos.y + 0.05) / 0.30, 0.0, 1.0) 
                                     * clamp((0.40 - pos.y) / 0.15, 0.0, 1.0);
                pos.y += uShoulderLift * 0.016 * shoulderFactor;

                // 2. HEAD & NECK BONE SKELETAL ROTATION (Pitch, Yaw, Roll, Translation)
                float headWeight = clamp((pos.y - 0.22) / 0.35, 0.0, 1.0);
                headWeight = headWeight * headWeight * (3.0 - 2.0 * headWeight); // smooth cubic ease
                if (headWeight > 0.0) {
                    float pivotY = 0.34;
                    vec3 rel = vec3(pos.x, pos.y - pivotY, pos.z);

                    // Pitch (Rotation around X - nod)
                    float pAngle = uHeadPitch * headWeight;
                    float cosP = cos(pAngle);
                    float sinP = sin(pAngle);
                    float y1 = rel.y * cosP - rel.z * sinP;
                    float z1 = rel.y * sinP + rel.z * cosP;
                    rel.y = y1;
                    rel.z = z1;

                    // Yaw (Rotation around Y - turn)
                    float yAngle = uHeadYaw * headWeight;
                    float cosY = cos(yAngle);
                    float sinY = sin(yAngle);
                    float x2 = rel.x * cosY + rel.z * sinY;
                    float z2 = -rel.x * sinY + rel.z * cosY;
                    rel.x = x2;
                    rel.z = z2;

                    // Roll (Rotation around Z - attentive tilt)
                    float rAngle = uHeadRoll * headWeight;
                    float cosR = cos(rAngle);
                    float sinR = sin(rAngle);
                    float x3 = rel.x * cosR - rel.y * sinR;
                    float y3 = rel.x * sinR + rel.y * cosR;
                    rel.x = x3;
                    rel.y = y3;

                    pos = vec3(rel.x, rel.y + pivotY, rel.z) + (uHeadOffset * headWeight);
                }

                // 3. HAIR SWAY INERTIA
                float hairFactor = clamp((pos.y - 0.15) / 0.60, 0.0, 1.0) * clamp(abs(pos.x) / 0.26, 0.0, 1.0);
                pos.x += sin(uTime * 2.6 + pos.y * 3.2) * (uHairSway * 0.015 * hairFactor);
                pos.z += cos(uTime * 2.2 + pos.x * 2.8) * (uHairSway * 0.010 * hairFactor);

                // 4. BLENDSHAPE: NATURAL MOUTH VISEME (Mouth region: y in [0.46, 0.58], |x| < 0.10)
                float mouthFactor = exp(-pow(pos.x / 0.08, 2.0)) * exp(-pow((pos.y - 0.52) / 0.07, 2.0));
                pos.y -= uMouthOpen * 0.020 * mouthFactor;
                pos.z += uMouthOpen * 0.012 * mouthFactor;

                // 5. BLENDSHAPE: FRIENDLY SMILE (Mouth corners lifted)
                float smileFactor = clamp((abs(pos.x) - 0.03) / 0.07, 0.0, 1.0) * exp(-pow((pos.y - 0.52) / 0.06, 2.0));
                pos.y += uMouthSmile * 0.012 * smileFactor;

                // 6. BLENDSHAPE: EYELID BLINK MORPH
                float eyeFactor = clamp((abs(pos.x) - 0.05) / 0.08, 0.0, 1.0) * clamp((0.26 - abs(pos.x)) / 0.08, 0.0, 1.0)
                                * clamp((pos.y - 0.58) / 0.06, 0.0, 1.0) * clamp((0.70 - pos.y) / 0.06, 0.0, 1.0);
                pos.y -= uEyeBlink * 0.016 * eyeFactor;

                vec4 worldPos = uModelMatrix * vec4(pos, 1.0);
                vWorldPos = worldPos.xyz;
                vNormal = normalize((uModelMatrix * vec4(norm, 0.0)).xyz);
                vTexCoordinate = uv;

                vec3 viewDir = normalize(uCameraPos - vWorldPos);
                vRim = 1.0 - max(0.0, dot(vNormal, viewDir));
                vRim = pow(vRim, 2.0);

                gl_Position = uMVPMatrix * vec4(pos, 1.0);
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;

            uniform sampler2D uTexture;
            uniform vec3 uRimColor;
            uniform float uRimIntensity;
            uniform float uHoloScan;

            varying vec3 vNormal;
            varying vec3 vWorldPos;
            varying vec2 vTexCoordinate;
            varying float vRim;

            void main() {
                vec4 texColor = texture2D(uTexture, vTexCoordinate);

                // Soft directional lighting from front-top-right
                vec3 lightDir = normalize(vec3(0.25, 0.65, 0.95));
                float diff = max(0.55, dot(vNormal, lightDir));

                // Cybernetic rim lighting
                vec3 rim = uRimColor * (vRim * uRimIntensity);

                // Subtle animated hologram scanline
                float scan = sin(vWorldPos.y * 36.0 + uHoloScan * 6.28) * 0.025 + 0.975;

                vec3 finalRgb = (texColor.rgb * diff * scan) + rim;
                gl_FragColor = vec4(finalRgb, texColor.a);
            }
        """
    }

    // Matrices
    private val modelMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    // Shader Program & Handles
    private var programHandle = 0
    private var mvpMatrixHandle = 0
    private var modelMatrixHandle = 0
    private var cameraPosHandle = 0
    private var timeHandle = 0

    // Skeletal Handles
    private var headPitchHandle = 0
    private var headYawHandle = 0
    private var headRollHandle = 0
    private var headOffsetHandle = 0
    private var shoulderLiftHandle = 0
    private var chestBreathingHandle = 0
    private var hairSwayHandle = 0

    // BlendShape Handles
    private var mouthOpenHandle = 0
    private var mouthSmileHandle = 0
    private var eyeBlinkHandle = 0

    // Material Handles
    private var textureHandle = 0
    private var rimColorHandle = 0
    private var rimIntensityHandle = 0
    private var holoScanHandle = 0

    // Attrib Handles
    private var positionHandle = 0
    private var normalHandle = 0
    private var texCoordHandle = 0

    // Textures for expressions
    private var texIdle = 0
    private var texThink = 0
    private var texSpeak = 0
    private var texHappy = 0

    // Mesh
    private var meshData: Mesh3DData? = null

    // State & Animation inputs (Thread-safe)
    @Volatile var assistantState: AssistantState = AssistantState.IDLE
    @Volatile var audioAmplitude: Float = 0f
    @Volatile var manualPoseOverride: String? = null

    // Touch 3D Camera Orbit
    @Volatile var touchRotY = 0f
    @Volatile var touchRotX = 0f
    @Volatile var touchScale = 1.0f

    // Current Smoothed Bone States (Critical-Damped Springs)
    private var curHeadPitch = 0.0f
    private var curHeadYaw = 0.0f
    private var curHeadRoll = 0.0f
    private var curHeadOffsetZ = 0.0f
    private var curShoulderLift = 0.0f
    private var curBreathing = 0.0f
    private var curMouthOpen = 0.0f
    private var curMouthSmile = 0.0f
    private var curEyeBlink = 0.0f

    // Natural Blinking State Machine
    private var nextBlinkTime = SystemClock.uptimeMillis() + 3200L
    private var blinkStartTime = 0L
    private var isBlinking = false
    private var pendingDoubleBlink = false

    // Multi-frequency non-repeating organic wave generator
    private fun organicWave(time: Float, speed: Float, seed: Float): Float {
        return (sin(time * speed + seed) * 0.52f +
                sin(time * speed * 1.618f + seed * 2.31f) * 0.32f +
                sin(time * speed * 0.382f + seed * 0.77f) * 0.16f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f) // Transparent canvas
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        // Compile Shaders
        programHandle = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        mvpMatrixHandle = GLES20.glGetUniformLocation(programHandle, "uMVPMatrix")
        modelMatrixHandle = GLES20.glGetUniformLocation(programHandle, "uModelMatrix")
        cameraPosHandle = GLES20.glGetUniformLocation(programHandle, "uCameraPos")
        timeHandle = GLES20.glGetUniformLocation(programHandle, "uTime")

        headPitchHandle = GLES20.glGetUniformLocation(programHandle, "uHeadPitch")
        headYawHandle = GLES20.glGetUniformLocation(programHandle, "uHeadYaw")
        headRollHandle = GLES20.glGetUniformLocation(programHandle, "uHeadRoll")
        headOffsetHandle = GLES20.glGetUniformLocation(programHandle, "uHeadOffset")
        shoulderLiftHandle = GLES20.glGetUniformLocation(programHandle, "uShoulderLift")
        chestBreathingHandle = GLES20.glGetUniformLocation(programHandle, "uChestBreathing")
        hairSwayHandle = GLES20.glGetUniformLocation(programHandle, "uHairSway")

        mouthOpenHandle = GLES20.glGetUniformLocation(programHandle, "uMouthOpen")
        mouthSmileHandle = GLES20.glGetUniformLocation(programHandle, "uMouthSmile")
        eyeBlinkHandle = GLES20.glGetUniformLocation(programHandle, "uEyeBlink")

        textureHandle = GLES20.glGetUniformLocation(programHandle, "uTexture")
        rimColorHandle = GLES20.glGetUniformLocation(programHandle, "uRimColor")
        rimIntensityHandle = GLES20.glGetUniformLocation(programHandle, "uRimIntensity")
        holoScanHandle = GLES20.glGetUniformLocation(programHandle, "uHoloScan")

        positionHandle = GLES20.glGetAttribLocation(programHandle, "aPosition")
        normalHandle = GLES20.glGetAttribLocation(programHandle, "aNormal")
        texCoordHandle = GLES20.glGetAttribLocation(programHandle, "aTexCoordinate")

        // Load Textures
        texIdle = loadTexture(R.drawable.krish_anime_idle)
        texThink = loadTexture(R.drawable.krish_anime_think)
        texSpeak = loadTexture(R.drawable.krish_anime_speak)
        texHappy = loadTexture(R.drawable.krish_anime_happy)

        // Load 3D Mesh
        meshData = GlbModelLoader.loadGlbModel(context, customGlbFile) ?: GlbModelLoader.createProceduralAnimeMesh()
        Log.i(TAG, "KRISH AI 3D Animation Engine initialized with ${meshData?.vertexCount} vertices")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat()
        // 38° FOV perfectly scales the upper body to fit without clipping
        Matrix.perspectiveM(projectionMatrix, 0, 38.0f, ratio, 0.5f, 50.0f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val mesh = meshData ?: return
        val now = SystemClock.uptimeMillis()
        val timeSec = (now % 10000000L) / 1000.0f

        // Effective State
        val effectiveState = when (manualPoseOverride) {
            "idle" -> AssistantState.IDLE
            "listen" -> AssistantState.LISTENING
            "think" -> AssistantState.THINKING
            "speak" -> AssistantState.SPEAKING
            "happy" -> AssistantState.IDLE
            else -> assistantState
        }
        val isHappyPose = manualPoseOverride == "happy"

        // 1. PHYSIOLOGICALLY REALISTIC BLINKING ENGINE
        if (!isBlinking && now >= nextBlinkTime) {
            isBlinking = true
            blinkStartTime = now
        }

        var blinkProgress = 0.0f
        if (isBlinking) {
            val elapsed = now - blinkStartTime
            blinkProgress = when {
                elapsed < 45L -> (elapsed / 45.0f) // Fast eyelid drop
                elapsed < 70L -> 1.0f // Brief contact
                elapsed < 155L -> 1.0f - ((elapsed - 70L) / 85.0f) // Smooth spring open
                else -> {
                    isBlinking = false
                    // 18% chance of immediate organic double-blink
                    if (!pendingDoubleBlink && Math.random() < 0.18) {
                        pendingDoubleBlink = true
                        nextBlinkTime = now + 180L
                    } else {
                        pendingDoubleBlink = false
                        // Random interval between blinks depending on state
                        val minInterval = if (effectiveState == AssistantState.LISTENING) 4200L else 2800L
                        val variance = (Math.random() * 2600.0).toLong()
                        nextBlinkTime = now + minInterval + variance
                    }
                    0.0f
                }
            }
        }
        curEyeBlink += (blinkProgress.coerceIn(0f, 1f) - curEyeBlink) * 0.40f

        // 2. ASYMMETRICAL 40/60 BREATHING CYCLE
        // 40% inhale, 60% exhale for human respiratory timing
        val breathPeriod = 3.4f
        val breathPhase = (timeSec / breathPeriod) % 1.0f
        val targetBreathing = if (breathPhase < 0.40f) {
            val t = breathPhase / 0.40f
            t * t * (3.0f - 2.0f * t) // smoothstep in
        } else {
            val t = (breathPhase - 0.40f) / 0.60f
            1.0f - (t * t * (3.0f - 2.0f * t)) // smoothstep out
        }
        curBreathing += (targetBreathing - curBreathing) * 0.08f

        // Shoulder lift directly coupled with breathing inhalation
        val targetShoulder = curBreathing * 0.85f + organicWave(timeSec, 0.4f, 2.0f) * 0.15f
        curShoulderLift += (targetShoulder - curShoulderLift) * 0.08f

        // 3. ORGANIC HEAD MICRO-MOVEMENTS (To avoid robotic repetition)
        val idlePitch = organicWave(timeSec, 0.75f, 1.2f) * 0.024f  // subtle nod (~1.3°)
        val idleYaw   = organicWave(timeSec, 0.55f, 3.4f) * 0.038f  // subtle turn (~2.1°)
        val idleRoll  = organicWave(timeSec, 0.65f, 5.6f) * 0.020f  // subtle tilt (~1.1°)

        // 4. BEHAVIOR-DRIVEN SKELETAL POSING
        var targetPitch = idlePitch
        var targetYaw = idleYaw
        var targetRoll = idleRoll
        var targetOffsetZ = 0.0f
        var targetMouthOpen = 0.0f
        var targetSmile = if (isHappyPose) 0.85f else 0.10f

        when (effectiveState) {
            AssistantState.LISTENING -> {
                // Attentive forward tilt towards user with gentle focus
                targetPitch = 0.065f + (idlePitch * 0.3f)
                targetYaw = idleYaw * 0.3f
                targetRoll = 0.095f + (idleRoll * 0.3f) // Attentive head tilt
                targetOffsetZ = 0.038f // Lean forward attentively
                targetSmile = 0.18f

                // Audio reactivity: voice volume creates subtle attentive micro-nods
                val voiceNod = (audioAmplitude.coerceIn(0f, 10f) / 22f).coerceAtMost(0.04f)
                targetPitch += voiceNod
            }
            AssistantState.THINKING -> {
                // Inquisitive head angle tilted slightly upwards and to the side
                targetPitch = -0.11f + (organicWave(timeSec, 0.9f, 2.1f) * 0.02f)
                targetYaw = 0.08f + (organicWave(timeSec, 0.7f, 0.8f) * 0.02f)
                targetRoll = -0.13f // Pensive tilt
                targetOffsetZ = -0.015f
                targetSmile = 0.05f
            }
            AssistantState.SPEAKING -> {
                // Conversational head gestures accompanying speech phrasing
                val speechNod = sin(timeSec * 7.2f) * 0.032f
                val speechSway = sin(timeSec * 3.6f) * 0.022f
                targetPitch = (idlePitch * 0.4f) + speechNod
                targetYaw = (idleYaw * 0.4f) + speechSway
                targetRoll = (idleRoll * 0.4f) + cos(timeSec * 4.0f) * 0.018f
                targetOffsetZ = 0.018f
                targetSmile = 0.25f

                // Natural, non-exaggerated speech phoneme lip-sync
                // Sits at natural ~5.5Hz conversational syllable cadence
                val syllablePulse = (sin(timeSec * 15.5f) * 0.5f + 0.5f)
                val audioBoost = (audioAmplitude.coerceIn(0f, 10f) / 10f) * 0.20f
                targetMouthOpen = (syllablePulse * 0.24f + audioBoost).coerceIn(0.04f, 0.36f)
            }
            AssistantState.IDLE -> {
                if (isHappyPose) {
                    targetPitch = -0.02f + sin(timeSec * 3.2f) * 0.025f // Warm affirmative nod
                    targetYaw = idleYaw * 0.4f
                    targetRoll = 0.06f
                    targetOffsetZ = 0.02f
                    targetSmile = 0.85f // Full friendly smile
                }
            }
            else -> { /* Retain default idle */ }
        }

        // Smooth critical-damped interpolation (no jerking or snapping)
        curHeadPitch   += (targetPitch - curHeadPitch) * 0.12f
        curHeadYaw     += (targetYaw - curHeadYaw) * 0.12f
        curHeadRoll    += (targetRoll - curHeadRoll) * 0.12f
        curHeadOffsetZ += (targetOffsetZ - curHeadOffsetZ) * 0.10f
        curMouthOpen   += (targetMouthOpen - curMouthOpen) * 0.26f
        curMouthSmile  += (targetSmile - curMouthSmile) * 0.12f

        // Camera setup centered on upper body
        val eyeX = 0.0f
        val eyeY = 0.08f
        val eyeZ = 2.55f / touchScale.coerceIn(0.8f, 1.8f)
        Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, 0.0f, 0.08f, 0.0f, 0.0f, 1.0f, 0.0f)

        // Model Matrix with soft spring return to center
        Matrix.setIdentityM(modelMatrix, 0)
        val floatOffset = sin(timeSec * 1.6f) * 0.018f
        Matrix.translateM(modelMatrix, 0, 0f, floatOffset, 0f)

        touchRotX *= 0.96f
        touchRotY *= 0.98f

        Matrix.rotateM(modelMatrix, 0, touchRotX, 1.0f, 0.0f, 0.0f)
        Matrix.rotateM(modelMatrix, 0, touchRotY, 0.0f, 1.0f, 0.0f)

        // Calculate MVP
        Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)

        GLES20.glUseProgram(programHandle)

        // State-responsive Cyber Rim Lighting
        val (rimR, rimG, rimB) = when {
            isHappyPose -> Triple(0.1f, 0.95f, 0.9f) // Warm Cyan
            effectiveState == AssistantState.LISTENING -> Triple(0.0f, 0.98f, 0.65f) // Cyber Green
            effectiveState == AssistantState.THINKING -> Triple(0.75f, 0.25f, 1.0f) // Neon Purple
            effectiveState == AssistantState.SPEAKING -> Triple(0.15f, 0.60f, 1.0f) // Electric Blue
            effectiveState == AssistantState.ERROR -> Triple(1.0f, 0.20f, 0.20f) // Alert Red
            else -> Triple(0.0f, 0.88f, 1.0f) // Neon Cyan
        }

        // Pass Uniforms
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(modelMatrixHandle, 1, false, modelMatrix, 0)
        GLES20.glUniform3f(cameraPosHandle, eyeX, eyeY, eyeZ)
        GLES20.glUniform1f(timeHandle, timeSec)

        // Skeletal Uniforms
        GLES20.glUniform1f(headPitchHandle, curHeadPitch)
        GLES20.glUniform1f(headYawHandle, curHeadYaw)
        GLES20.glUniform1f(headRollHandle, curHeadRoll)
        GLES20.glUniform3f(headOffsetHandle, 0.0f, 0.0f, curHeadOffsetZ)
        GLES20.glUniform1f(shoulderLiftHandle, curShoulderLift)
        GLES20.glUniform1f(chestBreathingHandle, curBreathing)
        GLES20.glUniform1f(hairSwayHandle, 1.0f + (audioAmplitude.coerceIn(0f, 10f) / 10f))

        // BlendShape Uniforms
        GLES20.glUniform1f(mouthOpenHandle, curMouthOpen)
        GLES20.glUniform1f(mouthSmileHandle, curMouthSmile)
        GLES20.glUniform1f(eyeBlinkHandle, curEyeBlink)

        // Material Uniforms
        GLES20.glUniform3f(rimColorHandle, rimR, rimG, rimB)
        GLES20.glUniform1f(rimIntensityHandle, 1.15f)
        GLES20.glUniform1f(holoScanHandle, (timeSec * 0.35f) % 1.0f)

        // Select expression texture map
        val activeTexture = when {
            isHappyPose || curMouthSmile > 0.60f -> texHappy
            effectiveState == AssistantState.THINKING -> texThink
            effectiveState == AssistantState.SPEAKING && (curMouthOpen > 0.16f) -> texSpeak
            curEyeBlink > 0.45f -> texHappy // Closed eyes for natural eyelid blink
            else -> texIdle
        }

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, activeTexture)
        GLES20.glUniform1i(textureHandle, 0)

        // Vertex Buffers
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.vertexBuffer)

        GLES20.glEnableVertexAttribArray(normalHandle)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.normalBuffer)

        GLES20.glEnableVertexAttribArray(texCoordHandle)
        GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, mesh.uvBuffer)

        // Draw 3D Mesh
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, mesh.indexCount, GLES20.GL_UNSIGNED_SHORT, mesh.indexBuffer)

        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(normalHandle)
        GLES20.glDisableVertexAttribArray(texCoordHandle)
    }

    private fun loadTexture(resId: Int): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        if (textures[0] == 0) return 0

        val options = BitmapFactory.Options().apply { inScaled = false }
        val bitmap = BitmapFactory.decodeResource(context.resources, resId, options) ?: return 0

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textures[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()
        return textures[0]
    }

    private fun createProgram(vShaderCode: String, fShaderCode: String): Int {
        val vShader = loadShader(GLES20.GL_VERTEX_SHADER, vShaderCode)
        val fShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fShaderCode)
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vShader)
        GLES20.glAttachShader(program, fShader)
        GLES20.glLinkProgram(program)
        return program
    }

    private fun loadShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            Log.e(TAG, "Shader compilation failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    fun setModelFile(file: File?) {
        customGlbFile = file
        meshData = GlbModelLoader.loadGlbModel(context, customGlbFile) ?: GlbModelLoader.createProceduralAnimeMesh()
    }
}
