package com.example.avatar

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Lightweight glTF 2.0 Binary (.glb) and VRM mesh parser for Android.
 * Extracts vertex positions, normals, UV texture coordinates, and index buffers.
 * Optimized for low memory footprint on 4GB RAM devices.
 */
data class Mesh3DData(
    val vertexBuffer: FloatBuffer,
    val normalBuffer: FloatBuffer,
    val uvBuffer: FloatBuffer,
    val indexBuffer: ShortBuffer,
    val vertexCount: Int,
    val indexCount: Int,
    val boundsRadius: Float = 1.2f
)

object GlbModelLoader {
    private const val TAG = "GlbModelLoader"
    private const val GLTF_MAGIC = 0x46546C67 // "glTF" in little-endian

    /**
     * Loads a 3D model from assets or external file.
     * Returns null if file is missing or invalid, triggering procedural 3D fallback.
     */
    fun loadGlbModel(context: Context, customFile: File? = null, assetPath: String = "models/krish_ai.glb"): Mesh3DData? {
        return try {
            val inputStream: InputStream = if (customFile != null && customFile.exists()) {
                customFile.inputStream()
            } else {
                context.assets.open(assetPath)
            }
            parseGlbStream(inputStream)
        } catch (e: Exception) {
            Log.w(TAG, "Notice: GLB asset load fallback (${e.message}). Using built-in 3D mesh.", e)
            null
        }
    }

    private fun parseGlbStream(stream: InputStream): Mesh3DData? {
        val bytes = stream.use { it.readBytes() }
        if (bytes.size < 20) return null

        val headerBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = headerBuffer.int
        val version = headerBuffer.int
        val length = headerBuffer.int

        if (magic != GLTF_MAGIC || version != 2) {
            Log.e(TAG, "Invalid GLB header magic: 0x${magic.toString(16)} or version: $version")
            return null
        }

        // Chunk 0: JSON metadata
        val chunk0Length = headerBuffer.int
        val chunk0Type = headerBuffer.int // 0x4E4F534A ("JSON")
        val jsonBytes = ByteArray(chunk0Length)
        headerBuffer.get(jsonBytes)
        val jsonStr = String(jsonBytes, Charsets.UTF_8)
        val gltfJson = JSONObject(jsonStr)

        // Chunk 1: Binary Buffer
        if (headerBuffer.remaining() < 8) return null
        val chunk1Length = headerBuffer.int
        val chunk1Type = headerBuffer.int // 0x004E4942 ("BIN")
        val binOffset = headerBuffer.position()

        // Parse Accessors & BufferViews
        val accessors = gltfJson.getJSONArray("accessors")
        val bufferViews = gltfJson.getJSONArray("bufferViews")

        val posAcc = accessors.getJSONObject(0)
        val normAcc = accessors.getJSONObject(1)
        val uvAcc = accessors.getJSONObject(2)
        val idxAcc = accessors.getJSONObject(3)

        val posBv = bufferViews.getJSONObject(posAcc.getInt("bufferView"))
        val normBv = bufferViews.getJSONObject(normAcc.getInt("bufferView"))
        val uvBv = bufferViews.getJSONObject(uvAcc.getInt("bufferView"))
        val idxBv = bufferViews.getJSONObject(idxAcc.getInt("bufferView"))

        val vertexCount = posAcc.getInt("count")
        val indexCount = idxAcc.getInt("count")

        val posOffset = binOffset + posBv.getInt("byteOffset")
        val normOffset = binOffset + normBv.getInt("byteOffset")
        val uvOffset = binOffset + uvBv.getInt("byteOffset")
        val idxOffset = binOffset + idxBv.getInt("byteOffset")

        // Allocate Direct Buffers for OpenGL ES
        val vertexBuffer = ByteBuffer.allocateDirect(vertexCount * 3 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        val normalBuffer = ByteBuffer.allocateDirect(vertexCount * 3 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        val uvBuffer = ByteBuffer.allocateDirect(vertexCount * 2 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        val indexBuffer = ByteBuffer.allocateDirect(indexCount * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()

        val rawBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        // Read positions
        rawBuffer.position(posOffset)
        for (i in 0 until vertexCount * 3) {
            vertexBuffer.put(rawBuffer.float)
        }
        vertexBuffer.position(0)

        // Read normals
        rawBuffer.position(normOffset)
        for (i in 0 until vertexCount * 3) {
            normalBuffer.put(rawBuffer.float)
        }
        normalBuffer.position(0)

        // Read UVs
        rawBuffer.position(uvOffset)
        for (i in 0 until vertexCount * 2) {
            uvBuffer.put(rawBuffer.float)
        }
        uvBuffer.position(0)

        // Read indices
        rawBuffer.position(idxOffset)
        for (i in 0 until indexCount) {
            indexBuffer.put(rawBuffer.short)
        }
        indexBuffer.position(0)

        Log.d(TAG, "Successfully parsed GLB model: $vertexCount vertices, $indexCount indices")
        return Mesh3DData(
            vertexBuffer = vertexBuffer,
            normalBuffer = normalBuffer,
            uvBuffer = uvBuffer,
            indexBuffer = indexBuffer,
            vertexCount = vertexCount,
            indexCount = indexCount
        )
    }

    /**
     * Generates a clean, seamless, continuous 3D anime character mesh.
     * Guaranteed zero broken geometry or duplicate parts.
     */
    fun createProceduralAnimeMesh(): Mesh3DData {
        val vertexList = ArrayList<Float>()
        val normalList = ArrayList<Float>()
        val uvList = ArrayList<Float>()
        val indexList = ArrayList<Short>()

        val cols = 24
        val rows = 30
        val xMin = -0.60f
        val xMax = 0.60f
        val yMin = -0.85f
        val yMax = 0.88f

        val frontGrid = Array(rows + 1) { ShortArray(cols + 1) }

        // 1. Front 3D continuous surface
        for (r in 0..rows) {
            val fy = r.toFloat() / rows.toFloat()
            val y = yMin + fy * (yMax - yMin)

            for (c in 0..cols) {
                val fc = c.toFloat() / cols.toFloat()
                val x = xMin + fc * (xMax - xMin)

                var z = 0.0f
                if (y > 0.30f) {
                    val dx = x / 0.30f
                    val dy = (y - 0.58f) / 0.30f
                    val r2 = dx * dx + dy * dy
                    if (r2 < 1.0f) {
                        z = sqrt(max(0.0f, 1.0f - r2)) * 0.15f
                    } else {
                        z = -0.03f
                    }
                } else if (y > -0.20f) {
                    val dx = x / 0.40f
                    if (kotlin.math.abs(dx) < 1.0f) {
                        z = 0.09f * (1.0f - dx * dx)
                    }
                } else {
                    val dx = x / 0.35f
                    if (kotlin.math.abs(dx) < 1.0f) {
                        z = 0.05f * (1.0f - dx * dx)
                    }
                }

                val u = ((x - xMin) / (xMax - xMin)).coerceIn(0f, 1f)
                val v = ((yMax - y) / (yMax - yMin)).coerceIn(0f, 1f)

                val idx = (vertexList.size / 3).toShort()
                vertexList.addAll(listOf(x, y, z))
                normalList.addAll(listOf(0f, 0f, 1f))
                uvList.addAll(listOf(u, v))
                frontGrid[r][c] = idx
            }
        }

        // Triangulate front
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val i0 = frontGrid[r][c]
                val i1 = frontGrid[r][c + 1]
                val i2 = frontGrid[r + 1][c + 1]
                val i3 = frontGrid[r + 1][c]
                indexList.addAll(listOf(i0, i1, i2, i0, i2, i3))
            }
        }

        // 2. Back volumetric shell
        val backGrid = Array(rows + 1) { ShortArray(cols + 1) }
        for (r in 0..rows) {
            val fy = r.toFloat() / rows.toFloat()
            val y = yMin + fy * (yMax - yMin)

            for (c in 0..cols) {
                val fc = c.toFloat() / cols.toFloat()
                val x = xMin + fc * (xMax - xMin)
                val frontIdx = frontGrid[r][c].toInt()
                val fz = vertexList[frontIdx * 3 + 2]
                val bz = min(-0.05f, -fz - 0.05f)

                val idx = (vertexList.size / 3).toShort()
                vertexList.addAll(listOf(x, y, bz))
                normalList.addAll(listOf(0f, 0f, -1f))
                uvList.addAll(listOf(0.05f, 0.05f))
                backGrid[r][c] = idx
            }
        }

        // Triangulate back
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val i0 = backGrid[r][c]
                val i1 = backGrid[r][c + 1]
                val i2 = backGrid[r + 1][c + 1]
                val i3 = backGrid[r + 1][c]
                indexList.addAll(listOf(i0, i2, i1, i0, i3, i2))
            }
        }

        // Connect side seams
        for (r in 0 until rows) {
            val f0 = frontGrid[r][0]
            val f1 = frontGrid[r + 1][0]
            val b0 = backGrid[r][0]
            val b1 = backGrid[r + 1][0]
            indexList.addAll(listOf(f0, b0, b1, f0, b1, f1))

            val rf0 = frontGrid[r][cols]
            val rf1 = frontGrid[r + 1][cols]
            val rb0 = backGrid[r][cols]
            val rb1 = backGrid[r + 1][cols]
            indexList.addAll(listOf(rf0, rb1, rb0, rf0, rf1, rb1))
        }

        val numVertices = vertexList.size / 3
        val numIndices = indexList.size

        val vBuf = ByteBuffer.allocateDirect(vertexList.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        vertexList.forEach { vBuf.put(it) }
        vBuf.position(0)

        val nBuf = ByteBuffer.allocateDirect(normalList.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        normalList.forEach { nBuf.put(it) }
        nBuf.position(0)

        val uvBuf = ByteBuffer.allocateDirect(uvList.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        uvList.forEach { uvBuf.put(it) }
        uvBuf.position(0)

        val iBuf = ByteBuffer.allocateDirect(indexList.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        indexList.forEach { iBuf.put(it) }
        iBuf.position(0)

        return Mesh3DData(
            vertexBuffer = vBuf,
            normalBuffer = nBuf,
            uvBuffer = uvBuf,
            indexBuffer = iBuf,
            vertexCount = numVertices,
            indexCount = numIndices
        )
    }
}
