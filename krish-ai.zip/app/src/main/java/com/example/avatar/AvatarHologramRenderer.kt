package com.example.avatar

import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AssistantState
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberYellow
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-fidelity reactive Hologram & Live Anime Avatar renderer.
 * Features natural breathing, procedural eye blinking, state-specific character poses,
 * dynamic audio waveform lip-sync, and cybernetic HUD rings.
 */
class AvatarHologramRenderer : AvatarRendererContract {

    @Composable
    override fun RenderAvatar(
        state: AssistantState,
        audioAmplitude: Float,
        modifier: Modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "AvatarPulse")

        // Idle floating breathing animation
        val floatOffset by infiniteTransition.animateFloat(
            initialValue = -8f,
            targetValue = 8f,
            animationSpec = infiniteRepeatable(
                animation = tween(2800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "FloatOffset"
        )

        // Continuous HUD rotation
        val hudRotation by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = if (state == AssistantState.THINKING) 3500 else 18000,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "HudRotation"
        )

        // Hologram scanline sweep
        val scanlineY by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(2400, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "ScanlineY"
        )

        // Speaking mouth / wave animation
        val talkingPulse by infiniteTransition.animateFloat(
            initialValue = 0.85f,
            targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                animation = tween(180, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "TalkingPulse"
        )

        // Natural eye blinking timer
        var isBlinking by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(3200 + (1000..2500).random().toLong())
                isBlinking = true
                delay(130)
                isBlinking = false
            }
        }

        // State-responsive glow color
        val glowColor = when (state) {
            AssistantState.IDLE -> NeonCyan
            AssistantState.LISTENING -> CyberGreen
            AssistantState.THINKING -> NeonPurple
            AssistantState.SPEAKING -> ElectricBlue
            AssistantState.ERROR -> CyberRed
        }

        // Smooth amplitude reaction for listening / speaking
        val reactiveScale by animateFloatAsState(
            targetValue = when (state) {
                AssistantState.LISTENING -> 1f + (audioAmplitude.coerceIn(0f, 10f) / 45f)
                AssistantState.SPEAKING -> talkingPulse
                AssistantState.THINKING -> 1.02f
                else -> 1f
            },
            animationSpec = tween(120),
            label = "ReactiveScale"
        )

        // Active expression drawable
        val activeDrawableRes = when {
            isBlinking -> R.drawable.krish_anime_happy // Closed eyes for natural blinking
            state == AssistantState.THINKING -> R.drawable.krish_anime_think
            state == AssistantState.SPEAKING -> R.drawable.krish_anime_speak
            else -> R.drawable.krish_anime_idle
        }

        Box(
            modifier = modifier,
            contentAlignment = Alignment.Center
        ) {
            // Background futuristic HUD orbit rings and energy ripples
            Canvas(
                modifier = Modifier.size(310.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.width / 2.2f

                // Outer dashed targeting ring
                rotate(hudRotation, center) {
                    drawCircle(
                        color = glowColor.copy(alpha = 0.35f),
                        radius = baseRadius,
                        center = center,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 18f), 0f)
                        )
                    )

                    // Reticle marker ticks
                    for (i in 0 until 4) {
                        val angle = Math.toRadians((i * 90.0))
                        val start = Offset(
                            (center.x + (baseRadius - 12f) * cos(angle)).toFloat(),
                            (center.y + (baseRadius - 12f) * sin(angle)).toFloat()
                        )
                        val end = Offset(
                            (center.x + (baseRadius + 12f) * cos(angle)).toFloat(),
                            (center.y + (baseRadius + 12f) * sin(angle)).toFloat()
                        )
                        drawLine(
                            color = glowColor.copy(alpha = 0.8f),
                            start = start,
                            end = end,
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                }

                // Reverse spinning inner ring for thinking state
                if (state == AssistantState.THINKING) {
                    rotate(-hudRotation * 1.5f, center) {
                        drawCircle(
                            color = NeonPurple.copy(alpha = 0.6f),
                            radius = baseRadius * 0.85f,
                            center = center,
                            style = Stroke(
                                width = 3.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 30f), 0f)
                            )
                        )
                    }
                }

                // Reactive listening soundwave halos
                if (state == AssistantState.LISTENING) {
                    val listeningRadius = baseRadius * reactiveScale
                    drawCircle(
                        color = CyberGreen.copy(alpha = 0.45f),
                        radius = listeningRadius,
                        center = center,
                        style = Stroke(width = 3.dp.toPx())
                    )
                    drawCircle(
                        color = CyberGreen.copy(alpha = 0.2f),
                        radius = listeningRadius * 1.12f,
                        center = center,
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }

                // Speaking waveform rings
                if (state == AssistantState.SPEAKING) {
                    drawCircle(
                        color = ElectricBlue.copy(alpha = 0.5f),
                        radius = baseRadius * talkingPulse,
                        center = center,
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }
            }

            // Anime-girl Assistant Avatar Core
            Box(
                modifier = Modifier
                    .offset(y = floatOffset.dp)
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                glowColor.copy(alpha = 0.25f),
                                CyberDark.copy(alpha = 0.95f)
                            )
                        )
                    )
                    .border(
                        width = 2.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                glowColor,
                                NeonPurple,
                                glowColor.copy(alpha = 0.3f),
                                glowColor
                            )
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Character image with smooth crossfade between expressions
                Crossfade(targetState = activeDrawableRes, label = "PoseTransition") { resId ->
                    Image(
                        painter = painterResource(id = resId),
                        contentDescription = "KRISH AI Assistant Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .drawWithContent {
                                drawContent()

                                // Holographic cyan/purple color tint overlay
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            glowColor.copy(alpha = 0.12f),
                                            Color.Transparent,
                                            glowColor.copy(alpha = 0.22f)
                                        )
                                    ),
                                    blendMode = BlendMode.Screen
                                )

                                // Animated scanline effect
                                val scanY = size.height * scanlineY
                                drawLine(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            glowColor.copy(alpha = 0.7f),
                                            Color.Transparent
                                        )
                                    ),
                                    start = Offset(0f, scanY),
                                    end = Offset(size.width, scanY),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }
                    )
                }

                // Speaking mouth / audio visualizer overlay indicator at the bottom of the portrait
                if (state == AssistantState.SPEAKING) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 20.dp)
                    ) {
                        SpeakingVoiceWaveform(color = glowColor, pulse = talkingPulse)
                    }
                }
            }
        }
    }

    @Composable
    private fun SpeakingVoiceWaveform(color: Color, pulse: Float) {
        Canvas(modifier = Modifier.size(width = 80.dp, height = 24.dp)) {
            val barCount = 7
            val barWidth = 4.dp.toPx()
            val spacing = (size.width - (barCount * barWidth)) / (barCount - 1)
            val centerY = size.height / 2f

            for (i in 0 until barCount) {
                val x = i * (barWidth + spacing)
                val heightMultiplier = when (i) {
                    0, 6 -> 0.35f * pulse
                    1, 5 -> 0.65f * (2f - pulse)
                    2, 4 -> 0.9f * pulse
                    else -> 1.0f * (1.5f - pulse * 0.5f)
                }
                val barHeight = (size.height * heightMultiplier).coerceIn(4.dp.toPx(), size.height)
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, centerY - barHeight / 2f),
                    size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )
            }
        }
    }
}
