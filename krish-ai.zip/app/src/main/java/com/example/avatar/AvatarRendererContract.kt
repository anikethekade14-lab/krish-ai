package com.example.avatar

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.model.AssistantState

/**
 * Strategy interface for rendering KRISH AI's visual avatar.
 * Supports both lightweight reactive holographic rendering (default for low-RAM devices)
 * and external 3D GLB/VRM engines.
 */
interface AvatarRendererContract {
    @Composable
    fun RenderAvatar(
        state: AssistantState,
        audioAmplitude: Float,
        modifier: Modifier
    )
}
