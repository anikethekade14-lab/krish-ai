package com.example.avatar

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream

/**
 * Architectural specification for loading and rendering 3D GLB/VRM assets.
 * Supports bundled assets (assets/models/krish_ai.glb) as well as custom user-imported
 * .glb or .vrm files from local storage.
 */
data class Model3DSpec(
    val assetFileName: String = "models/krish_ai.glb",
    val modelScale: Float = 1.0f,
    val isVrmFormat: Boolean = false,
    val preferredFps: Int = 60
)

object Model3DManager {
    private const val TAG = "Model3DManager"
    private var customModelFile: File? = null

    /**
     * Checks if a 3D asset has been added to assets or internal storage
     */
    fun is3DModelAvailable(context: Context, spec: Model3DSpec = Model3DSpec()): Boolean {
        if (customModelFile?.exists() == true) return true
        return try {
            val list = context.assets.list("models") ?: emptyArray()
            list.contains(File(spec.assetFileName).name)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Import a custom .glb or .vrm file from a Uri (picked by user via SAF)
     */
    fun importModelFromUri(context: Context, uri: Uri): Result<File> {
        return try {
            val modelsDir = File(context.filesDir, "models").apply { mkdirs() }
            val destFile = File(modelsDir, "imported_avatar.glb")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return Result.failure(Exception("Could not open input stream for Uri"))

            customModelFile = destFile
            Log.i(TAG, "Successfully imported custom 3D model: ${destFile.absolutePath} (${destFile.length()} bytes)")
            Result.success(destFile)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to import model from Uri", e)
            Result.failure(e)
        }
    }

    fun setCustomModelFile(file: File) {
        if (file.exists()) {
            customModelFile = file
        }
    }

    fun clearCustomModel(context: Context) {
        customModelFile = null
        try {
            val file = File(context.filesDir, "models/imported_avatar.glb")
            if (file.exists()) file.delete()
        } catch (_: Exception) {}
    }

    fun getModelFile(): File? = customModelFile
}
