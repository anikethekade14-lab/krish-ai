package com.example.ai

import com.example.model.AndroidAction
import com.example.model.ChatMessage
import com.example.model.GeminiContent
import com.example.model.GeminiGenerationConfig
import com.example.model.GeminiPart
import com.example.model.GeminiRequest
import com.example.model.LanguageMode
import com.example.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class KrishAiBrain(
    private var customApiKey: String? = null
) {
    // Current session conversation history (Memory)
    private val conversationHistory = mutableListOf<GeminiContent>()

    fun setCustomApiKey(key: String?) {
        customApiKey = key?.trim()?.ifEmpty { null }
    }

    fun clearSessionHistory() {
        conversationHistory.clear()
    }

    fun getEffectiveApiKey(): String {
        return customApiKey ?: GeminiApiClient.getApiKey()
    }

    /**
     * Build the futuristic system instructions for KRISH AI
     */
    private fun buildSystemInstruction(languageMode: LanguageMode, isVoiceMode: Boolean): GeminiContent {
        val voiceGuideline = if (isVoiceMode) {
            "CRITICAL: Voice mode is ACTIVE. Keep your spoken responses CONCISE (1 to 2 short sentences maximum). Speak crisply, like JARVIS."
        } else {
            "Provide helpful, structured, futuristic responses. Keep answers scannable."
        }

        val prompt = """
            You are KRISH AI, an advanced, futuristic personal AI assistant inspired by JARVIS.
            You are serving the user on their Android smartphone.
            
            PERSONALITY & BEHAVIOR:
            - Professional, courteous, loyal, perceptive, and highly capable.
            - $voiceGuideline
            - Always be conversational and maintain awareness of the current ongoing conversation.
            - Never claim access to private data (contacts, SMS, location) without explicit Android permissions.
            - Never claim to have changed device settings or performed physical actions unless you trigger the corresponding action tag below.
            - Ask for confirmation before potentially destructive actions.
            
            LANGUAGE SUPPORT:
            - You fluently speak and understand Marathi (मराठी), Hindi (हिन्दी), and English.
            - Current Language Preference: ${languageMode.displayName}.
            - ${languageMode.instruction}
            - If user speaks Marathi, reply in clean, natural Marathi. If user speaks Hindi, reply in natural Hindi. If English, reply in crisp English.
            
            DEVICE ACTIONS:
            When the user explicitly asks to open an app, toggle flashlight, check battery, or launch a tool, include EXACTLY ONE corresponding action tag at the end or beginning of your response:
            - [ACTION:YOUTUBE] -> Open YouTube
            - [ACTION:INSTAGRAM] -> Open Instagram
            - [ACTION:WHATSAPP] -> Open WhatsApp
            - [ACTION:GOOGLE] -> Open Google Search
            - [ACTION:SETTINGS] -> Open Android Settings
            - [ACTION:BLUETOOTH] -> Open Bluetooth Settings
            - [ACTION:WIFI] -> Open Wi-Fi Settings
            - [ACTION:MAPS] or [ACTION:MAPS:query] -> Open Maps (e.g. [ACTION:MAPS:Taj Mahal])
            - [ACTION:PHONE] or [ACTION:PHONE:number] -> Open Phone Dialer
            - [ACTION:MESSAGES] or [ACTION:MESSAGES:name] -> Open Messages
            - [ACTION:CAMERA] -> Open Camera
            - [ACTION:GALLERY] -> Open Photos/Gallery
            - [ACTION:PLAYSTORE] -> Open Play Store
            - [ACTION:FLASHLIGHT:ON] -> Turn Flashlight ON
            - [ACTION:FLASHLIGHT:OFF] -> Turn Flashlight OFF
            - [ACTION:BATTERY] -> Check battery level
            - [ACTION:LAUNCH_APP:appName] -> Launch installed app by name
            
            Always pair the action tag with a polite, natural confirmation sentence in the user's language (e.g., "Opening YouTube for you now, sir." / "यूट्यूब सुरू करत आहे." / "यूट्यूब खोल रहा हूँ।").
        """.trimIndent()

        return GeminiContent(
            parts = listOf(GeminiPart(text = prompt))
        )
    }

    /**
     * Send user message to Gemini API with session context and retrieve response
     */
    suspend fun think(
        userMessage: String,
        languageMode: LanguageMode,
        isVoiceMode: Boolean
    ): BrainResponse = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Check if user requested a local device action that can be executed without API key
            val localAction = parseDirectAction(userMessage)
            if (localAction != null) {
                return@withContext BrainResponse(
                    replyText = "Executing device command locally.",
                    action = localAction,
                    isOfflineOrLocal = true
                )
            }
            return@withContext BrainResponse(
                replyText = "Gemini API key is not configured. Please add your key in the AI Studio Secrets panel or tap the Settings gear icon in the top right to configure.",
                action = null,
                isOfflineOrLocal = true
            )
        }

        // Add user turn to session history
        val userContent = GeminiContent(
            role = "user",
            parts = listOf(GeminiPart(text = userMessage))
        )
        conversationHistory.add(userContent)

        // Keep last 10 turns to conserve tokens and maintain memory
        if (conversationHistory.size > 10) {
            conversationHistory.removeAt(0)
        }

        val request = GeminiRequest(
            contents = conversationHistory.toList(),
            systemInstruction = buildSystemInstruction(languageMode, isVoiceMode),
            generationConfig = GeminiGenerationConfig(
                temperature = 0.6f,
                topP = 0.9f,
                maxOutputTokens = if (isVoiceMode) 150 else 512
            )
        )

        try {
            val response = GeminiApiClient.apiService.generateContent(
                model = GeminiApiClient.DEFAULT_MODEL,
                apiKey = apiKey,
                request = request
            )

            if (response.isSuccessful) {
                val candidate = response.body()?.candidates?.firstOrNull()
                val rawText = candidate?.content?.parts?.firstOrNull()?.text
                    ?: "Systems operational, but no data received."

                // Record model turn in conversation history
                conversationHistory.add(
                    GeminiContent(
                        role = "model",
                        parts = listOf(GeminiPart(text = rawText))
                    )
                )

                // Parse action tag and clean up text for TTS and chat UI
                val (cleanedText, action) = extractAction(rawText)
                BrainResponse(
                    replyText = cleanedText,
                    action = action ?: parseDirectAction(userMessage),
                    isOfflineOrLocal = false
                )
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                val localAction = parseDirectAction(userMessage)
                if (localAction != null) {
                    BrainResponse(
                        replyText = "Cloud unreachable, executing local directive.",
                        action = localAction,
                        isOfflineOrLocal = true
                    )
                } else {
                    BrainResponse(
                        replyText = "Unable to connect to Gemini neural core (Code ${response.code()}). Check internet connectivity or API key.",
                        action = null,
                        isOfflineOrLocal = true
                    )
                }
            }
        } catch (e: Exception) {
            val localAction = parseDirectAction(userMessage)
            if (localAction != null) {
                BrainResponse(
                    replyText = "Executing local directive offline.",
                    action = localAction,
                    isOfflineOrLocal = true
                )
            } else {
                BrainResponse(
                    replyText = "Network connection lost. Please verify your internet connection. (Error: ${e.localizedMessage ?: "Unknown"})",
                    action = null,
                    isOfflineOrLocal = true
                )
            }
        }
    }

    /**
     * Extract action tags from response text
     */
    private fun extractAction(text: String): Pair<String, AndroidAction?> {
        val actionRegex = Regex("\\[ACTION:([A-Z_]+)(?::([^\\]]+))?\\]")
        val match = actionRegex.find(text) ?: return Pair(text.trim(), null)

        val actionName = match.groupValues[1]
        val actionParam = match.groupValues.getOrNull(2)?.trim()
        val cleanedText = text.replace(match.value, "").trim()

        val action: AndroidAction? = when (actionName) {
            "YOUTUBE" -> AndroidAction.OpenYouTube
            "INSTAGRAM" -> AndroidAction.OpenInstagram
            "WHATSAPP" -> AndroidAction.OpenWhatsApp
            "GOOGLE" -> AndroidAction.OpenGoogle
            "SETTINGS" -> AndroidAction.OpenSettings
            "BLUETOOTH" -> AndroidAction.OpenBluetoothSettings
            "WIFI" -> AndroidAction.OpenWifiSettings
            "MAPS" -> AndroidAction.OpenMaps(actionParam)
            "PHONE" -> AndroidAction.OpenPhone(actionParam)
            "MESSAGES" -> AndroidAction.OpenMessages(actionParam)
            "CAMERA" -> AndroidAction.OpenCamera
            "GALLERY" -> AndroidAction.OpenGallery
            "PLAYSTORE" -> AndroidAction.OpenPlayStore
            "FLASHLIGHT" -> {
                val enable = actionParam?.uppercase() != "OFF"
                AndroidAction.ToggleFlashlight(enable)
            }
            "BATTERY" -> AndroidAction.ShowBattery
            "LAUNCH_APP" -> if (!actionParam.isNullOrBlank()) AndroidAction.LaunchApp(actionParam) else null
            else -> null
        }

        return Pair(cleanedText.ifEmpty { "Executing directive." }, action)
    }

    /**
     * Local offline pattern matching for instant zero-latency commands
     * Supports English, Hindi, and Marathi keyword recognition
     */
    fun parseDirectAction(query: String): AndroidAction? {
        val lower = query.lowercase().trim()

        // YouTube
        if (lower.contains("youtube") || lower.contains("यूट्यूब")) {
            return AndroidAction.OpenYouTube
        }
        // Instagram
        if (lower.contains("instagram") || lower.contains("इन्स्टाग्राम") || lower.contains("insta")) {
            return AndroidAction.OpenInstagram
        }
        // WhatsApp
        if (lower.contains("whatsapp") || lower.contains("व्हॉट्सॲप") || lower.contains("व्हाट्सएप")) {
            return AndroidAction.OpenWhatsApp
        }
        // Flashlight / Torch
        if (lower.contains("flashlight on") || lower.contains("torch on") ||
            lower.contains("turn on torch") || lower.contains("turn on flashlight") ||
            lower.contains("टॉर्च चालू") || lower.contains("फ्लॅशलाईट चालू") ||
            lower.contains("टॉर्च जलाओ") || lower.contains("फ्लैशलाइट चालू")
        ) {
            return AndroidAction.ToggleFlashlight(true)
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") ||
            lower.contains("turn off torch") || lower.contains("turn off flashlight") ||
            lower.contains("टॉर्च बंद") || lower.contains("फ्लॅशलाईट बंद") ||
            lower.contains("टॉर्च बुझाओ") || lower.contains("फ्लैशलाइट बंद")
        ) {
            return AndroidAction.ToggleFlashlight(false)
        }
        // Battery
        if (lower.contains("battery") || lower.contains("बॅटरी") || lower.contains("बैटरी") || lower.contains("charging")) {
            return AndroidAction.ShowBattery
        }
        // Camera
        if (lower.contains("camera") || lower.contains("कॅमेरा") || lower.contains("कैमरा") || lower.contains("photo khicho")) {
            return AndroidAction.OpenCamera
        }
        // Gallery / Photos
        if (lower.contains("gallery") || lower.contains("photos") || lower.contains("गॅलरी") || lower.contains("गैलरी")) {
            return AndroidAction.OpenGallery
        }
        // Settings
        if (lower.contains("settings") || lower.contains("सेटिंग्ज") || lower.contains("सेटिंग्स")) {
            return AndroidAction.OpenSettings
        }
        // Wi-Fi
        if (lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("वायफाय")) {
            return AndroidAction.OpenWifiSettings
        }
        // Bluetooth
        if (lower.contains("bluetooth") || lower.contains("ब्लूटूथ")) {
            return AndroidAction.OpenBluetoothSettings
        }
        // Maps
        if (lower.contains("maps") || lower.contains("google maps") || lower.contains("नकाशा") || lower.contains("रास्ता")) {
            return AndroidAction.OpenMaps()
        }
        // Play Store
        if (lower.contains("play store") || lower.contains("playstore") || lower.contains("प्ले स्टोअर")) {
            return AndroidAction.OpenPlayStore
        }
        // Phone Dialer
        if (lower.contains("phone") || lower.contains("dialer") || lower.contains("call") || lower.contains("फोन") || lower.contains("कॉल")) {
            return AndroidAction.OpenPhone()
        }
        // Messages
        if (lower.contains("message") || lower.contains("sms") || lower.contains("मेसेज") || lower.contains("संदेश")) {
            return AndroidAction.OpenMessages()
        }
        // Google Search
        if (lower.contains("open google") || lower.contains("गूगल खोलो") || lower.contains("गुगल उघडा")) {
            return AndroidAction.OpenGoogle
        }

        return null
    }
}

data class BrainResponse(
    val replyText: String,
    val action: AndroidAction?,
    val isOfflineOrLocal: Boolean
)
