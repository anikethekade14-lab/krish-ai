package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.KrishAiBrain
import com.example.model.AndroidAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KRISH AI", appName)
  }

  @Test
  fun `test offline intent parsing for youtube`() {
    val brain = KrishAiBrain()
    val action = brain.parseDirectAction("please open youtube")
    assertNotNull(action)
    assertTrue(action is AndroidAction.OpenYouTube)
  }

  @Test
  fun `test offline intent parsing for marathi torch command`() {
    val brain = KrishAiBrain()
    val action = brain.parseDirectAction("टॉर्च चालू करा")
    assertNotNull(action)
    assertTrue(action is AndroidAction.ToggleFlashlight)
    assertEquals(true, (action as AndroidAction.ToggleFlashlight).enable)
  }

  @Test
  fun `test procedural 3d anime mesh generation`() {
    val mesh = com.example.avatar.GlbModelLoader.createProceduralAnimeMesh()
    assertNotNull(mesh)
    assertTrue(mesh.vertexCount > 0)
    assertTrue(mesh.indexCount > 0)
    assertEquals(mesh.vertexCount * 3, mesh.vertexBuffer.capacity())
    assertEquals(mesh.vertexCount * 3, mesh.normalBuffer.capacity())
    assertEquals(mesh.vertexCount * 2, mesh.uvBuffer.capacity())
  }

  @Test
  fun `test 3d model manager asset availability`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val isAvailable = com.example.avatar.Model3DManager.is3DModelAvailable(context)
    // Bundled krish_ai.glb is in assets/models/
    assertTrue(isAvailable)
  }

  @Test
  fun `test load bundled clean glb model`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val mesh = com.example.avatar.GlbModelLoader.loadGlbModel(context)
    assertNotNull(mesh)
    assertTrue(mesh!!.vertexCount > 0)
    assertTrue(mesh.indexCount > 0)
  }
}

